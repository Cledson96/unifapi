<?php
  include "db_connection.php";

  $id = substr($_SERVER['REQUEST_URI'],1);
  $id = explode('/',$id);
  $id = end($id);

  $id_obra = $_GET['id'];

  $del_users = mysqli_query($conn, "DELETE FROM tbl_obra WHERE id_obra = $id_obra");

  if ($del_users == 1){
    header("Location: ../obras.php?msg=deu_certo");
  }
  else{
    header("Location: ../obras.php?msg=erro");
  }
?>